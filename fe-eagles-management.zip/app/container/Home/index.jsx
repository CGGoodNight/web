import React, { Component } from "react";
import Nav from "../Nav";

class HomePage extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <Nav>
        这是首页
      </Nav>
    );
  }
}

export default HomePage;