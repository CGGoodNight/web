/**
 * 声明整个系统的全局变量
 */
let globalVar = {};
export { globalVar };
