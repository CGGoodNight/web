## Memos

> 技术架构：本备忘录使用react+react-router+redux+less+ES6+webpack实现;

>页面UI参照：

> 在线演示地址：

### 功能说明



### 待解决


### 本地演示方法

```text
# 安装依赖
npm install
# 本地运行
npm run start
# 导出文件到build文件夹
npm run build
# 运行地址
localhost:3000
```

### 相关截图



**移动端页面:**

![移动端端页面]
