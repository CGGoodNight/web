module.exports = {
    // 此处使用postcss的插件
    plugins: [
        require('autoprefixer')
    ],
};
